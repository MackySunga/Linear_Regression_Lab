// Utils + math helpers
(function(){
  function isFiniteNumber(x){ return typeof x === 'number' && Number.isFinite(x); }
  function mean(arr){ return arr.reduce((a,b)=>a+b,0)/arr.length; }
  function variance(arr){ const mu = mean(arr); return arr.reduce((s,v)=>s+(v-mu)*(v-mu),0)/arr.length; }
  function covariance(x, y){ const mx = mean(x), my = mean(y); let s = 0; for(let i=0;i<x.length;i++){ s += (x[i]-mx)*(y[i]-my); } return s/x.length; }
  function linearFit(x, y){
    const varX = variance(x);
    const covXY = covariance(x, y);
    const m = varX === 0 ? 0 : covXY / varX;
    const b = mean(y) - m * mean(x);
    const yhat = x.map(xi => m*xi + b);
    const ssRes = y.reduce((s, yi, i)=> s + (yi - yhat[i])**2, 0);
    const ssTot = y.reduce((s, yi)=> s + (yi - mean(y))**2, 0);
    const r2 = ssTot === 0 ? 1 : 1 - ssRes/ssTot;
    const mse = ssRes / y.length;
    const residStd = Math.sqrt(mse);
    return { m, b, r2, mse, residStd };
  }
  function mseForLine(x, y, m, b){ let sse = 0; for(let i=0;i<x.length;i++){ const e = y[i] - (m*x[i] + b); sse += e*e; } return sse / x.length; }
  function nice(num, digits=4){ if(!Number.isFinite(num)) return '—'; return (Math.round(num * (10**digits))/(10**digits)).toString(); }
  function quantile(arr, q){ if(arr.length===0) return NaN; const s=[...arr].sort((a,b)=>a-b); const pos=(s.length-1)*q; const base=Math.floor(pos); const rest=pos-base; if(s[base+1]!==undefined){ return s[base]+rest*(s[base+1]-s[base]); } else { return s[base]; } }
  function median(arr){ return quantile(arr, 0.5); }
  function mad(arr){ const med = median(arr); const dev = arr.map(v=>Math.abs(v-med)); return median(dev); }
  function mode(arr){ const freq = new Map(); for(const v of arr){ const k = Math.round(v*1000)/1000; freq.set(k, (freq.get(k)||0)+1); } let best=null, count=0; for(const [k,c] of freq){ if(c>count){ count=c; best=k; } } if(count<=1) return null; return +best; }
  function sum(arr){ return arr.reduce((a,b)=>a+b,0); }
  function cssVar(name){ return getComputedStyle(document.body).getPropertyValue(name).trim(); }
  function unique(arr){ return Array.from(new Set(arr.map(v => v==null? 'NA' : v))); }
  function isAllNumeric(arr){ return arr.length>0 && arr.every(v => typeof v === 'number' && Number.isFinite(v)); }
  function discreteColors(n){ const base = ['#60a5fa','#34d399','#f472b6','#f59e0b','#a78bfa','#fb7185','#22d3ee','#84cc16','#e879f9','#f97316','#14b8a6','#eab308']; const out=[]; for(let i=0;i<n;i++){ out.push(base[i % base.length]); } return out; }
  function symbolCatalog(){ return ['circle','square','diamond','cross','x','triangle-up','triangle-down','triangle-left','triangle-right','star','hexagram','hourglass']; }
  function computeIQRBox(arr){ const q1 = quantile(arr, 0.25); const q3 = quantile(arr, 0.75); const iqr = q3 - q1; return { q1, q3, iqr }; }

  window.Utils = { isFiniteNumber, mean, variance, covariance, linearFit, mseForLine, nice, quantile, median, mad, mode, sum, cssVar, unique, isAllNumeric, discreteColors, symbolCatalog, computeIQRBox };
})();