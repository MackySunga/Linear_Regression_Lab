(function(){
  const U = window.Utils;

  // ======= DOM elements ======= //
  const fileInput = document.getElementById('fileInput');
  const btnDemo = document.getElementById('btnDemo');
  const btnReset = document.getElementById('btnReset');
  const xSelect = document.getElementById('xSelect');
  const ySelect = document.getElementById('ySelect');
  const colorBySelect = document.getElementById('colorBySelect');
  const symbolBySelect = document.getElementById('symbolBySelect');
  const markerSymbolSelect = document.getElementById('markerSymbolSelect');
  const markerSizeInput = document.getElementById('markerSizeInput');
  const btnPlot = document.getElementById('btnPlot');
  const plotDiv = document.getElementById('plot');

  const mSlider = document.getElementById('mSlider');
  const bSlider = document.getElementById('bSlider');
  const bandSlider = document.getElementById('bandSlider');
  const mNum = document.getElementById('mNum');
  const bNum = document.getElementById('bNum');
  const bandNum = document.getElementById('bandNum');
  const mVal = document.getElementById('mVal');
  const bVal = document.getElementById('bVal');
  const bandVal = document.getElementById('bandVal');

  const olsEq = document.getElementById('olsEq');
  const r2El = document.getElementById('r2');
  const mseEl = document.getElementById('mse');
  const dM = document.getElementById('deltaM');
  const dB = document.getElementById('deltaB');
  const toggleOLS = document.getElementById('toggleOLS');
  const themeSelect = document.getElementById('themeSelect');

  // Diagnostics elements
  const centralsTableBody = document.getElementById('centralsBody');
  const dispersionTableBody = document.getElementById('dispersionBody');
  const freqColorDiv = document.getElementById('freqColor');
  const freqSymbolDiv = document.getElementById('freqSymbol');
  const freqJointDiv = document.getElementById('freqJoint');
  const freqColorLabel = document.getElementById('freqColorLabel');
  const freqSymbolLabel = document.getElementById('freqSymbolLabel');
  const scopeSelect = document.getElementById('scopeSelect');
  const scopeCounts = document.getElementById('scopeCounts');

  // Outlier controls
  const outlierModeSel = document.getElementById('outlierMode');
  const iqrControls = document.getElementById('iqrControls');
  const residControls = document.getElementById('residControls');
  const customControls = document.getElementById('customControls');
  const iqrKInput = document.getElementById('iqrK');
  const residThreshSpan = document.getElementById('residThresh');
  const gateXMin = document.getElementById('gateXMin');
  const gateXMax = document.getElementById('gateXMax');
  const gateYMin = document.getElementById('gateYMin');
  const gateYMax = document.getElementById('gateYMax');
  const btnSetIQR = document.getElementById('btnSetIQR');
  const btnSetDataBounds = document.getElementById('btnSetDataBounds');
  const topNSelect = document.getElementById('topN');
  const outlierListDiv = document.getElementById('outlierList');
  const downloadOutliersLink = document.getElementById('downloadOutliers');

  // Self-tests
  const btnRunTests = document.getElementById('btnRunTests');
  const testSummary = document.getElementById('testSummary');
  const testDetails = document.getElementById('testDetails');

  // ======= State ======= //
  let rawRows = [];
  let X = [], Y = [];
  let headersAll = [];
  let numericHeaders = [];
  let ols = { m: 0, b: 0, r2: 0, mse: 0, residStd: 1 };
  let band = 1;
  let xMin = 0, xMax = 1;
  let yMinAll = 0, yMaxAll = 1;
  let lastRowsUsed = [];
  let lastOutliers = [];
  let lastColorKey = '';
  let lastSymbolKey = '';
  let viewportRanges = { x: null, y: null };
  let plotEventsAttached = false;

  // ======= Theme ======= //
  function setTheme(name){
    document.body.setAttribute('data-theme', name);
    plotAll();
  }

  // ======= CSV handling ======= //
  function parseCSV(file){
    return new Promise((resolve, reject)=>{
      if(!(window.Papa && Papa.parse)){
        alert('PapaParse is not loaded. For offline use, copy ./vendor/papaparse-5.4.1.min.js and refresh.');
        return reject(new Error('PapaParse missing'));
      }
      Papa.parse(file, { header: true, dynamicTyping: true, skipEmptyLines: true, complete: r => resolve(r.data), error: err => reject(err) });
    });
  }

  function detectNumericHeaders(rows){
    if(rows.length === 0) return [];
    const keys = Object.keys(rows[0]);
    const isNum = key => rows.some(r => typeof r[key] === 'number' && Number.isFinite(r[key]));
    return keys.filter(isNum);
  }

  function populateAxisSelects(numericCols){
    xSelect.innerHTML = '';
    ySelect.innerHTML = '';
    for(const h of numericCols){
      const optX = document.createElement('option'); optX.value = h; optX.textContent = h; xSelect.appendChild(optX);
      const optY = document.createElement('option'); optY.value = h; optY.textContent = h; ySelect.appendChild(optY);
    }
    if(numericCols.length >= 2){ ySelect.selectedIndex = 1; }
  }

  function populateEncodingSelects(allCols){
    function fill(select){
      select.innerHTML = '<option value="">None</option>';
      for(const h of allCols){ const o = document.createElement('option'); o.value = h; o.textContent = h; select.appendChild(o); }
    }
    fill(colorBySelect);
    fill(symbolBySelect);
  }

  function setDataFromColumns(xKey, yKey){
    X = []; Y = [];
    for(const row of rawRows){
      const xv = row[xKey]; const yv = row[yKey];
      if(U.isFiniteNumber(xv) && U.isFiniteNumber(yv)) { X.push(+xv); Y.push(+yv); }
    }
    if(X.length < 2){ alert('Not enough numeric data to plot.'); return false; }
    xMin = Math.min(...X); xMax = Math.max(...X);
    if(xMin === xMax){ xMin -= 1; xMax += 1; }
    yMinAll = Math.min(...Y); yMaxAll = Math.max(...Y);
    ols = U.linearFit(X, Y);
    band = ols.residStd || 1;
    configureSliders();
    updateMetrics();
    return true;
  }

  // ======= Sliders & Metrics ======= //
  function configureSliders(){
    const yRange = Math.max(1e-6, yMaxAll - yMinAll);
    const xRange = Math.max(1e-6, xMax - xMin);
    const slopeScale = yRange / xRange;

    mSlider.min = (-10 * slopeScale).toString();
    mSlider.max = (10 * slopeScale).toString();
    mSlider.step = (slopeScale/500).toString();
    mSlider.value = ols.m; mNum.value = ols.m;

    bSlider.min = (yMinAll - yRange).toString();
    bSlider.max = (yMaxAll + yRange).toString();
    bSlider.step = (yRange/500).toString();
    bSlider.value = ols.b; bNum.value = ols.b;

    bandSlider.min = '0';
    bandSlider.max = (Math.max(3*ols.residStd, 0.1*yRange)).toString();
    bandSlider.step = (yRange/1000).toString();
    bandSlider.value = band; bandNum.value = band;

    mVal.textContent = U.nice(+mSlider.value, 4);
    bVal.textContent = U.nice(+bSlider.value, 4);
    bandVal.textContent = U.nice(+bandSlider.value, 4);

    olsEq.textContent = `y = ${U.nice(ols.m,4)}·x + ${U.nice(ols.b,4)}`;
    r2El.textContent = U.nice(ols.r2, 4);
  }

  function updateMetrics(){
    const m = +mSlider.value, b = +bSlider.value;
    const mse = U.mseForLine(X, Y, m, b);
    mseEl.textContent = U.nice(mse, 6);
    dM.textContent = U.nice(Math.abs(m - ols.m), 6);
    dB.textContent = U.nice(Math.abs(b - ols.b), 6);
    mVal.textContent = U.nice(m, 4);
    bVal.textContent = U.nice(b, 4);
    bandVal.textContent = U.nice(+bandSlider.value, 4);
    residThreshSpan.textContent = U.nice(+bandSlider.value, 4);
  }

  // ======= Plotting & Outliers ======= //
  function makeLineXY(m, b){ const xs = [xMin, xMax]; const ys = xs.map(x => m*x + b); return { xs, ys }; }

  function computeOutliers(rows){
    const mode = outlierModeSel.value;
    const m = +mSlider.value, b = +bSlider.value, bandW = +bandSlider.value;
    let rect = null; // {x0,x1,y0,y1}
    if(mode === 'iqr'){
      const Xs = rows.map(r=>r.x), Ys = rows.map(r=>r.y);
      const xb = U.computeIQRBox(Xs), yb = U.computeIQRBox(Ys); const k = +iqrKInput.value || 1.5;
      rect = { x0: xb.q1 - k*xb.iqr, x1: xb.q3 + k*xb.iqr, y0: yb.q1 - k*yb.iqr, y1: yb.q3 + k*yb.iqr };
    } else if(mode === 'custom'){
      rect = { x0: +gateXMin.value, x1: +gateXMax.value, y0: +gateYMin.value, y1: +gateYMax.value };
      if(![rect.x0,rect.x1,rect.y0,rect.y1].every(v => Number.isFinite(v))){ rect = null; }
    }

    const outliers = []; const inliers = [];
    for(let i=0;i<rows.length;i++){
      const r = rows[i];
      let isOut = false, severity = 0, resid = Math.abs(r.y - (m*r.x + b));
      if(outlierModeSel.value === 'residual'){
        isOut = resid > bandW;
        severity = resid - bandW;
      } else if(rect){
        const dx = (r.x < rect.x0) ? rect.x0 - r.x : (r.x > rect.x1 ? r.x - rect.x1 : 0);
        const dy = (r.y < rect.y0) ? rect.y0 - r.y : (r.y > rect.y1 ? r.y - rect.y1 : 0);
        severity = Math.hypot(dx, dy);
        isOut = dx>0 || dy>0;
      }
      const rec = { idx: r.idx, x: r.x, y: r.y, c: r.c, s: r.s, resid, severity };
      if(isOut) outliers.push(rec); else inliers.push(rec);
    }
    outliers.sort((a,b)=> b.severity - a.severity);
    return { outliers, inliers, rect };
  }

  function renderFrequencies(rows, colorKey, symbolKey){
    const N = rows.length;
    if(freqColorLabel) freqColorLabel.textContent = colorKey || '—';
    if(freqSymbolLabel) freqSymbolLabel.textContent = symbolKey || '—';

    function makeTable(map){
      const entries = Array.from(map.entries()); entries.sort((a,b)=> b[1]-a[1]);
      let html = `<table><thead><tr><th>Label</th><th>Count</th><th>%</th></tr></thead><tbody>`;
      for(const [k,v] of entries){ html += `<tr><td style="text-align:left;">${k}</td><td>${v}</td><td>${N? (100*v/N).toFixed(1):'0.0'}%</td></tr>`; }
      html += `<tr><th style="text-align:left;">Total</th><th>${N}</th><th>${N? '100%':'0%'}</th></tr></tbody></table>`;
      return html;
    }

    // Color-only
    if(freqColorDiv){
      if(colorKey){
        const map = new Map();
        const vals = rows.map(r=> r.c==null ? 'NA' : r.c);
        const many = U.isAllNumeric(vals) && U.unique(vals).length > 20;
        if(many){ freqColorDiv.innerHTML = '<em>Continuous label; frequencies not shown.</em>'; }
        else { vals.forEach(v=> map.set(v, (map.get(v)||0)+1)); freqColorDiv.innerHTML = makeTable(map); }
      } else { freqColorDiv.innerHTML = '<em>None</em>'; }
    }

    // Symbol-only
    if(freqSymbolDiv){
      if(symbolKey){
        const map = new Map();
        const vals = rows.map(r=> r.s==null ? 'NA' : r.s);
        const many = U.isAllNumeric(vals) && U.unique(vals).length > 20;
        if(many){ freqSymbolDiv.innerHTML = '<em>Continuous label; frequencies not shown.</em>'; }
        else { vals.forEach(v=> map.set(v, (map.get(v)||0)+1)); freqSymbolDiv.innerHTML = makeTable(map); }
      } else { freqSymbolDiv.innerHTML = '<em>None</em>'; }
    }

    // Joint
    if(freqJointDiv){
      if(colorKey || symbolKey){
        const map = new Map();
        for(const r of rows){ const ck = colorKey? (r.c==null? 'NA': r.c) : '—'; const sk = symbolKey? (r.s==null? 'NA' : r.s) : '—'; const key = `${ck} | ${sk}`; map.set(key, (map.get(key)||0)+1); }
        freqJointDiv.innerHTML = makeTable(map);
      } else { freqJointDiv.innerHTML = '<em>No labels selected.</em>'; }
    }
  }

  function renderDiagnostics(Xarr, Yarr){
    if(!centralsTableBody || !dispersionTableBody) return; // hard guard
    const stats = (arr)=>{
      if(!arr || arr.length===0) return { mu:NaN, med:NaN, mo:null, v:NaN, sd:NaN, q1:NaN, q3:NaN, iqr:NaN, mn:NaN, mx:NaN, rng:NaN, md:NaN };
      const mu = U.mean(arr), med = U.median(arr), mo = U.mode(arr);
      const v = U.variance(arr), sd = Math.sqrt(v);
      const q1 = U.quantile(arr,0.25), q3 = U.quantile(arr,0.75), iqr = q3-q1;
      const mn = Math.min(...arr), mx = Math.max(...arr), rng = mx - mn;
      const md = U.mad(arr);
      return { mu, med, mo, v, sd, q1, q3, iqr, mn, mx, rng, md };
    }
    const sx = stats(Xarr), sy = stats(Yarr);

    function row(label, fx, fy){ return `<tr><td style="text-align:left;">${label}</td><td>${U.nice(fx,4)}</td><td>${U.nice(fy,4)}</td></tr>`; }
    centralsTableBody.innerHTML =
      row('Mean', sx.mu, sy.mu) +
      row('Median', sx.med, sy.med) +
      row('Mode', sx.mo===null?'n/a':sx.mo, sy.mo===null?'n/a':sy.mo);

    dispersionTableBody.innerHTML =
      row('Min', sx.mn, sy.mn) +
      row('Q1', sx.q1, sy.q1) +
      row('Q3', sx.q3, sy.q3) +
      row('Max', sx.mx, sy.mx) +
      row('Range', sx.rng, sy.rng) +
      row('Variance', sx.v, sy.v) +
      row('Std Dev', sx.sd, sy.sd) +
      row('IQR', sx.iqr, sy.iqr) +
      row('MAD', sx.md, sy.md);
  }

  function renderOutlierList(outliers){
    if(!outlierListDiv) return;
    const N = parseInt(topNSelect.value,10) || 5;
    const top = outliers.slice(0, N);
    let html = '<table><thead><tr><th>#</th><th>x</th><th>y</th><th>severity</th><th>residual</th><th>color</th><th>symbol</th></tr></thead><tbody>';
    top.forEach((o,i)=>{ html += `<tr><td>${i+1}</td><td>${U.nice(o.x,4)}</td><td>${U.nice(o.y,4)}</td><td>${U.nice(o.severity,4)}</td><td>${U.nice(o.resid,4)}</td><td style="text-align:left;">${o.c==null?'':o.c}</td><td style="text-align:left;">${o.s==null?'':o.s}</td></tr>`; });
    html += `</tbody></table>`;
    outlierListDiv.innerHTML = html;

    // CSV download
    const rows = outliers.map(o => ({index:o.idx, x:o.x, y:o.y, residual:o.resid, severity:o.severity, color:o.c, symbol:o.s}));
    const header = Object.keys(rows[0]||{index:'',x:'',y:'',residual:'',severity:'',color:'',symbol:''});
    const csv = [header.join(','), ...rows.map(r=> header.map(h=> r[h]).join(','))].join('\n');
    const blob = new Blob([csv], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    if(downloadOutliersLink) downloadOutliersLink.href = url;
  }

  function filterRowsByScope(rows){
    if(scopeSelect && scopeSelect.value === 'viewport' && viewportRanges.x && viewportRanges.y){
      const [x0,x1] = viewportRanges.x; const [y0,y1] = viewportRanges.y;
      return rows.filter(r => r.x >= Math.min(x0,x1) && r.x <= Math.max(x0,x1) && r.y >= Math.min(y0,y1) && r.y <= Math.max(y0,y1));
    }
    return rows;
  }

  function updateSecondaryPanels(){
    if(lastRowsUsed.length===0) return;
    const scoped = filterRowsByScope(lastRowsUsed);
    if(scopeCounts) scopeCounts.textContent = `${scoped.length} / ${lastRowsUsed.length} points`;
    renderFrequencies(scoped, lastColorKey, lastSymbolKey);
    renderDiagnostics(scoped.map(r=>r.x), scoped.map(r=>r.y));
  }

  function attachPlotEventsOnce(){
    if(plotEventsAttached) return;
    plotDiv.on('plotly_relayout', (ev)=>{
      try{
        const x0 = ev['xaxis.range[0]'], x1 = ev['xaxis.range[1]'];
        const y0 = ev['yaxis.range[0]'], y1 = ev['yaxis.range[1]'];
        if([x0,x1,y0,y1].every(Number.isFinite)){
          viewportRanges.x = [x0, x1];
          viewportRanges.y = [y0, y1];
          updateSecondaryPanels();
        }
      }catch(_){}
    });
    plotEventsAttached = true;
  }

  function plotAll(){
    const gridCol = U.cssVar('--grid') || '#1f2937';
    const axisCol = U.cssVar('--axis') || '#cbd5e1';
    const markerSize = Math.max(3, Math.min(16, +markerSizeInput.value || 7));

    if(!window.Plotly){
      // Guard if Plotly stubbed/missing
      document.getElementById('libWarning')?.setAttribute('style','display:inline-block;');
      return;
    }

    if(X.length === 0){
      Plotly.react(plotDiv, [], {paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)'}, {responsive:true, displaylogo:false});
      return;
    }

    const xKey = xSelect.value, yKey = ySelect.value;
    const colorKey = colorBySelect.value || '';
    const symbolKey = symbolBySelect.value || '';
    const defSymbol = markerSymbolSelect.value || 'circle';
    lastColorKey = colorKey; lastSymbolKey = symbolKey;

    const rows = [];
    for(let i=0;i<rawRows.length;i++){
      const row = rawRows[i];
      const xv = row[xKey]; const yv = row[yKey];
      if(U.isFiniteNumber(xv) && U.isFiniteNumber(yv)){
        rows.push({ idx:i, x:+xv, y:+yv, c: colorKey? row[colorKey] : null, s: symbolKey? row[symbolKey] : null });
      }
    }
    lastRowsUsed = rows;

    // Build point traces
    const colorVals = rows.map(r => r.c);
    const symbolVals = rows.map(r => r.s);
    const colorU = colorKey ? U.unique(colorVals) : [];
    const symbolU = symbolKey ? U.unique(symbolVals) : [];
    const colorContinuous = colorKey && U.isAllNumeric(colorVals) && U.unique(colorVals).length > 12;

    let dataTraces = [];

    if(!colorKey && !symbolKey){
      dataTraces.push({ x: rows.map(r=>r.x), y: rows.map(r=>r.y), mode:'markers', type:'scatter', name:'Data', marker:{ size: markerSize, symbol: defSymbol } });
    } else if(colorContinuous){
      const symMap = {}; const symCats = symbolU; const symList = U.symbolCatalog();
      symCats.forEach((k,i)=> symMap[k] = symList[i % symList.length]);
      const symArr = symbolKey ? symbolVals.map(v => symMap[v==null?'NA':v]) : defSymbol;
      dataTraces.push({ x: rows.map(r=>r.x), y: rows.map(r=>r.y), mode:'markers', type:'scatter', name: colorKey + ' (colorbar)', marker: { size: markerSize, symbol: symArr, color: colorVals, colorscale: 'Turbo', showscale: true } });
    } else {
      const colorCats = colorKey ? colorU : [null];
      const symbolCats = symbolKey ? symbolU : [null];
      const colors = U.discreteColors(colorCats.length);
      const colorMap = {}; colorCats.forEach((k,i)=> colorMap[k] = colors[i % colors.length]);
      const symList = U.symbolCatalog();
      const symMap = {}; symbolCats.forEach((k,i)=> symMap[k] = symList[i % symList.length]);

      const groups = new Map();
      for(const r of rows){
        const ck = colorKey ? (r.c==null? 'NA' : r.c) : null;
        const sk = symbolKey ? (r.s==null? 'NA' : r.s) : null;
        const key = `${ck}|${sk}`;
        if(!groups.has(key)){
          const nameParts = [];
          if(colorKey) nameParts.push(`${colorKey}=${ck}`);
          if(symbolKey) nameParts.push(`${symbolKey}=${sk}`);
          groups.set(key, { x:[], y:[], name: nameParts.join(' • ') || 'Data', color: colorMap[ck], symbol: symbolKey? symMap[sk]: defSymbol });
        }
        const g = groups.get(key); g.x.push(r.x); g.y.push(r.y);
      }
      dataTraces = Array.from(groups.values()).map(g => ({ x:g.x, y:g.y, mode:'markers', type:'scatter', name:g.name, marker:{ size: markerSize, color: g.color, symbol: g.symbol } }));
    }

    // Outliers
    const { outliers, rect } = computeOutliers(rows);
    lastOutliers = outliers;
    const outlierTrace = { x: outliers.map(o=>o.x), y: outliers.map(o=>o.y), mode:'markers', type:'scatter', name:'Outliers', marker:{ size: markerSize+2, symbol:'x', color:'#ef4444', line:{width:1, color:'#ef4444'} } };

    // Your line + band + OLS
    const m = +mSlider.value, b = +bSlider.value, bandW = +bandSlider.value;
    const userLine = makeLineXY(m,b);
    const upper = { x: userLine.xs, y: userLine.ys.map(v => v + bandW), mode:'lines', line: { width: 0 }, name: 'Upper band', showlegend: false };
    const lower = { x: userLine.xs, y: userLine.ys.map(v => v - bandW), mode:'lines', fill: 'tonexty', fillcolor: 'rgba(34, 211, 238, 0.12)', line: { width: 0 }, name: 'Error band', hoverinfo: 'skip' };
    const lineTrace = { x: userLine.xs, y: userLine.ys, mode:'lines', name: 'Your line', line: { width: 3 } };
    const olsLine = makeLineXY(ols.m, ols.b);
    const olsTrace = { x: olsLine.xs, y: olsLine.ys, mode:'lines', name: 'OLS (target)', line: { width: 3, dash: 'dash' }, visible: toggleOLS.checked ? true : 'legendonly' };

    const layout = {
      paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
      margin: { l: 50, r: 20, t: 30, b: 50 },
      xaxis: { title: xSelect.value || 'X', zeroline: false, gridcolor: gridCol, tickfont:{color:axisCol}, titlefont:{color:axisCol} },
      yaxis: { title: ySelect.value || 'Y', zeroline: false, gridcolor: gridCol, tickfont:{color:axisCol}, titlefont:{color:axisCol} },
      legend: { orientation: 'h', y: 1.08 },
      shapes: []
    };

    if(outlierModeSel.value !== 'residual' && rect){
      layout.shapes.push({ type:'rect', x0: rect.x0, x1: rect.x1, y0: rect.y0, y1: rect.y1, line:{ color:'#10b981', width:2 }, fillcolor:'rgba(16,185,129,0.08)' });
    }

    Plotly.react(plotDiv, [...dataTraces, upper, lower, lineTrace, olsTrace, outlierTrace], layout, {responsive: true, displaylogo: false}).then(()=>{
      // Initialize viewport ranges to current ranges shown
      try {
        const xRange = plotDiv.layout.xaxis.range || [Math.min(...rows.map(r=>r.x)), Math.max(...rows.map(r=>r.x))];
        const yRange = plotDiv.layout.yaxis.range || [Math.min(...rows.map(r=>r.y)), Math.max(...rows.map(r=>r.y))];
        viewportRanges.x = [xRange[0], xRange[1]];
        viewportRanges.y = [yRange[0], yRange[1]];
      } catch(_) {}
      updateSecondaryPanels();
      attachPlotEventsOnce();
    });
  }

  // ======= Events ======= //
  fileInput.addEventListener('change', async (e)=>{
    if(!e.target.files || e.target.files.length === 0) return;
    try {
      rawRows = await parseCSV(e.target.files[0]);
      if(!rawRows || rawRows.length === 0){ alert('No rows found in CSV.'); return; }
      headersAll = Object.keys(rawRows[0]);
      numericHeaders = detectNumericHeaders(rawRows);
      if(numericHeaders.length < 2){ alert('Could not find at least two numeric columns.'); return; }
      populateAxisSelects(numericHeaders);
      populateEncodingSelects(headersAll);
    } catch(err){ console.error(err); alert('Failed to parse CSV.'); }
  });

  btnDemo.addEventListener('click', ()=>{
    const n = 120; rawRows = [];
    for(let i=0;i<n;i++){
      const x = -10 + 20*Math.random();
      const grp = (i%3===0? 'A' : (i%3===1? 'B' : 'C'));
      const y = 2.5*x + (grp==='A'?3:grp==='B'?6:0) + (Math.random()*6 - 3);
      rawRows.push({ X: x, Y: y, Group: grp, Fold: i%5, Noise: (Math.random()*6-3) });
    }
    headersAll = Object.keys(rawRows[0]);
    numericHeaders = detectNumericHeaders(rawRows);
    populateAxisSelects(numericHeaders);
    populateEncodingSelects(headersAll);
    xSelect.value = 'X'; ySelect.value = 'Y';
    colorBySelect.value = 'Group';
    symbolBySelect.value = '';
    setDataFromColumns('X','Y');
    // initialize custom rectangle to IQR of demo
    const rows = rawRows.map((r,i)=>({idx:i,x:r.X,y:r.Y}));
    const xb = U.computeIQRBox(rows.map(r=>r.x)), yb = U.computeIQRBox(rows.map(r=>r.y));
    const k = +iqrKInput.value || 1.5;
    gateXMin.value = xb.q1 - k*xb.iqr; gateXMax.value = xb.q3 + k*xb.iqr;
    gateYMin.value = yb.q1 - k*yb.iqr; gateYMax.value = yb.q3 + k*yb.iqr;
    plotAll();
  });

  btnReset.addEventListener('click', ()=>{
    rawRows = []; headersAll = []; numericHeaders = []; X = []; Y = []; ols = {m:0,b:0,r2:0,mse:0,residStd:1};
    xSelect.innerHTML = ''; ySelect.innerHTML = ''; fileInput.value = '';
    colorBySelect.innerHTML = '<option value="">None</option>';
    symbolBySelect.innerHTML = '<option value="">None</option>';
    markerSymbolSelect.value = 'circle';
    markerSizeInput.value = 7;
    olsEq.textContent = '—'; r2El.textContent = '—'; mseEl.textContent = '—'; dM.textContent = '—'; dB.textContent = '—';
    if(centralsTableBody) centralsTableBody.innerHTML = '';
    if(dispersionTableBody) dispersionTableBody.innerHTML = '';
    if(freqColorDiv) freqColorDiv.innerHTML = '';
    if(freqSymbolDiv) freqSymbolDiv.innerHTML = '';
    if(freqJointDiv) freqJointDiv.innerHTML = '';
    if(outlierListDiv) outlierListDiv.innerHTML = '';
    Plotly.purge(plotDiv);
  });

  btnPlot.addEventListener('click', ()=>{ if(!xSelect.value || !ySelect.value){ alert('Choose X and Y columns first.'); return; } if(!setDataFromColumns(xSelect.value, ySelect.value)) return; plotAll(); });
  [xSelect, ySelect].forEach(sel => sel.addEventListener('change', ()=>{ if(rawRows.length === 0) return; if(!setDataFromColumns(xSelect.value, ySelect.value)) return; plotAll(); }));
  [colorBySelect, symbolBySelect, markerSymbolSelect, markerSizeInput].forEach(el => el.addEventListener('change', ()=>{ plotAll(); }));
  function syncSlider(slider, num){ slider.addEventListener('input', ()=>{ num.value = slider.value; updateMetrics(); plotAll(); }); num.addEventListener('input', ()=>{ slider.value = num.value; updateMetrics(); plotAll(); }); }
  syncSlider(mSlider, mNum); syncSlider(bSlider, bNum); syncSlider(bandSlider, bandNum);

  toggleOLS.addEventListener('change', ()=> plotAll());
  themeSelect.addEventListener('change', ()=> setTheme(themeSelect.value));
  scopeSelect.addEventListener('change', ()=> updateSecondaryPanels());

  outlierModeSel.addEventListener('change', ()=>{ const m=outlierModeSel.value; iqrControls.style.display = (m==='iqr')? 'block':'none'; residControls.style.display = (m==='residual')? 'block':'none'; customControls.style.display = (m==='custom')? 'grid':'none'; plotAll(); });
  iqrKInput.addEventListener('input', ()=> plotAll());
  [gateXMin, gateXMax, gateYMin, gateYMax].forEach(el => el.addEventListener('input', ()=> plotAll()));
  btnSetIQR.addEventListener('click', ()=>{
    if(lastRowsUsed.length===0) return; const Xs = lastRowsUsed.map(r=>r.x), Ys = lastRowsUsed.map(r=>r.y); const xb = U.computeIQRBox(Xs), yb = U.computeIQRBox(Ys); const k = +iqrKInput.value || 1.5; gateXMin.value = xb.q1 - k*xb.iqr; gateXMax.value = xb.q3 + k*xb.iqr; gateYMin.value = yb.q1 - k*yb.iqr; gateYMax.value = yb.q3 + k*yb.iqr; plotAll();
  });
  btnSetDataBounds.addEventListener('click', ()=>{ if(lastRowsUsed.length===0) return; const Xs = lastRowsUsed.map(r=>r.x), Ys = lastRowsUsed.map(r=>r.y); gateXMin.value = Math.min(...Xs); gateXMax.value = Math.max(...Xs); gateYMin.value = Math.min(...Ys); gateYMax.value = Math.max(...Ys); plotAll(); });

  topNSelect.addEventListener('change', ()=> renderOutlierList(lastOutliers));

  // ======= Self‑tests ======= //
  function runSelfTests(){
    const tests = [];
    function ok(name, cond){ tests.push({name, pass: !!cond, detail: cond? 'OK' : 'Failed'}); }

    // DOM presence
    ok('Has centrals body', !!centralsTableBody);
    ok('Has dispersion body', !!dispersionTableBody);
    ok('Has freq sections', !!freqColorDiv && !!freqSymbolDiv && !!freqJointDiv);
    ok('Has outlier list', !!outlierListDiv);

    // Math checks
    const xs = [1,2,3,4,5]; const ys = xs.map(v => 2*v + 1);
    const fit = U.linearFit(xs, ys);
    ok('OLS slope ~ 2', Math.abs(fit.m - 2) < 1e-9);
    ok('OLS intercept ~ 1', Math.abs(fit.b - 1) < 1e-9);
    ok('R^2 = 1', Math.abs(fit.r2 - 1) < 1e-12);

    // Outlier residual mode
    const rows = xs.map((x,i)=> ({idx:i, x, y: ys[i]}));
    const prevM = mSlider.value, prevB = bSlider.value, prevBand = bandSlider.value, prevMode = outlierModeSel.value;
    mSlider.value = 2; bSlider.value = 1; bandSlider.value = 0.1; outlierModeSel.value = 'residual';
    const r1 = computeOutliers(rows);
    ok('Residual mode: 0 outliers on perfect fit', r1.outliers.length === 0);

    // IQR mode simple
    outlierModeSel.value = 'iqr';
    const rows2 = [{x:1,y:1},{x:2,y:2},{x:3,y:3},{x:100,y:100}].map((r,i)=>({...r,idx:i}));
    const r2 = computeOutliers(rows2);
    ok('IQR mode: identifies far outlier', r2.outliers.length >= 1);

    // Restore sliders/mode
    mSlider.value = prevM; bSlider.value = prevB; bandSlider.value = prevBand; outlierModeSel.value = prevMode; updateMetrics();

    // Report
    const passCount = tests.filter(t=>t.pass).length;
    const outHtml = '<table><thead><tr><th>Test</th><th>Result</th></tr></thead><tbody>' + tests.map(t=>`<tr><td style="text-align:left;">${t.name}</td><td>${t.pass? '✅ PASS' : '❌ FAIL'} ${t.pass?'':('— '+t.detail)}</td></tr>`).join('') + '</tbody></table>';
    if(testSummary) testSummary.textContent = `${passCount}/${tests.length} tests passed`;
    if(testDetails) testDetails.innerHTML = outHtml;
  }
  if(btnRunTests){ btnRunTests.addEventListener('click', runSelfTests); }

  // Initialize
  setTheme('dark');
  residControls.style.display = 'none';
  customControls.style.display = 'none';
  if(window.Plotly && Plotly.newPlot){
    Plotly.newPlot(plotDiv, [], {paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)'}, {responsive:true, displaylogo:false});
  } else {
    document.getElementById('libWarning')?.setAttribute('style','display:inline-block;');
  }
  attachPlotEventsOnce();
})();