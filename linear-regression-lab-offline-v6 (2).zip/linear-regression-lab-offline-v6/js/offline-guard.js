// Offline library presence check + safe stubs
(function(){
  var warnEl = null;
  function setWarn(msg){
    if(!warnEl) warnEl = document.getElementById('libWarning');
    if(warnEl){
      warnEl.style.display = 'inline-block';
      warnEl.style.borderColor = 'var(--warn)';
      warnEl.textContent = msg;
    } else {
      console.warn(msg);
    }
  }

  // Plotly guard
  if(!window.Plotly){
    window.Plotly = {
      react: function(div){ if(div){ div.innerHTML = '<div class="pill">Plotly not loaded — copy <b>vendor/plotly-2.35.2.min.js</b> and refresh.</div>'; } return Promise.resolve(); },
      newPlot: function(div){ if(div){ div.innerHTML = '<div class="pill">Plotly not loaded — copy <b>vendor/plotly-2.35.2.min.js</b> and refresh.</div>'; } return Promise.resolve(); },
      purge: function(div){ if(div){ div.innerHTML = ''; } }
    };
    setWarn('Missing Plotly. Place plotly-2.35.2.min.js in ./vendor/');
  }

  // PapaParse guard
  if(!window.Papa){
    setWarn((warnEl && warnEl.textContent ? warnEl.textContent + ' ' : '') + 'Missing PapaParse. Place papaparse-5.4.1.min.js in ./vendor/');
  }
})();