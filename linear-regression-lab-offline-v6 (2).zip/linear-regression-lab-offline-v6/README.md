# Linear Regression Lab — Offline Multi-file (v6)

A tidy, classroom-friendly web app to explore linear regression **fully offline**:

- CSV upload → select X/Y
- Adjustable line (slope/intercept) + shaded error band
- OLS reference line + equation + R²
- Color-by & Symbol-by encodings
- Diagnostics (central tendencies, dispersion)
- Frequencies for labels + joint table
- Outlier tools: Residual, IQR (k×IQR), Custom rectangle; green inlier region
- Scope selector: stats can respect current viewport or all plotted points
- Top-N outliers list + CSV download
- Light/Dark theme
- Built-in self-tests

## How to run offline
1. Put **two files** in the `vendor/` folder (exact filenames):
   - `plotly-2.35.2.min.js`
   - `papaparse-5.4.1.min.js`
2. Open `index.html` in a modern browser (Chrome/Edge/Firefox/Safari).
3. If a yellow warning pill appears under the title, a vendor file is missing or misnamed.

> Tip: You can also serve the folder via a simple local server (e.g., `python -m http.server`) if your environment restricts local file URLs.

## Structure
```
linear-regression-lab-offline-v6/
  index.html
  css/
    styles.css
  js/
    offline-guard.js
    utils.js
    app.js
  vendor/
    plotly-2.35.2.min.js        # you add this
    papaparse-5.4.1.min.js      # you add this
  assets/
    demo.csv
  README.md
```